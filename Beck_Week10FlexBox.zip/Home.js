import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { Button, StyleSheet, Text, View } from 'react-native';

const Home = ({ navigation }) => {
  
  const goToFirst = () => {
    navigation.navigate('First');
  }

  const goToSecond = () => {
    navigation.navigate('Second');
  }
  
  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        First Screen
      </Text>
      <Button style={title}
	          title="Go to First Screen"
              onPress={goToFirst} />
      <Button style={title}
	          title="Go to Second Screen"
              onPress={goToSecond} />
      <StatusBar style="auto" />
    </View>
  );
}

export default FirstScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
	alignItems: 'center',
	justifyContent: 'space-evenly'
  },
  title: {
    fontSize: 36,
    marginBottom: 20
	alignItems: 'center',
	justifyContent: 'space-enenly'
  }
});

import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const ReturnToHome = ({ navigation }) => {

  const goToHome = () => {
    navigation.navigate('Home');
  }
}

export default function FirstScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.item}>
        <Text style={styles.title}>These</Text>
	  </View>
      <View style={styles.item}>
        <Text style={styles.title}>Are</Text>
	  </View>
      <View style={styles.item}>
        <Text style={styles.title}>Flex Items</Text>
	  </View>
      <StatusBar style="auto" />
	</View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#7F7F7F',
    flexDirection: 'column',
	  alignItems: 'center',
    justifyContent: 'center'
  },
  item: {
    backgroundColor: '#F0F0F0',
	  width: 300,
	  height: 150,
    margin: 20,
  },
  title: {
	  fontSize: 32,
    textAlign: 'center',
    margin: 'auto'
  }
});
